package udp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPClient2 {
    public static void main(String[] args) throws Exception {
        DatagramSocket socket = new DatagramSocket(34568);
        byte[] buffer = new byte[1024];

        // recibir el número del servidor
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.receive(packet);
        String numeroTxt = new String(packet.getData(), 0, packet.getLength()).trim();

        // calcular el factorial
        int numero = Integer.parseInt(numeroTxt);
        int factorial = 1;
        for (int i = 1; i <= numero; i++) {
            factorial *= i;
        }
        String factorialTxt = Integer.toString(factorial);

        // enviar el factorial al servidor
        InetAddress address = InetAddress.getLocalHost();
        buffer = factorialTxt.getBytes();
        packet = new DatagramPacket(buffer, buffer.length, address, 12345);
        socket.send(packet);

        socket.close();
    }
}


