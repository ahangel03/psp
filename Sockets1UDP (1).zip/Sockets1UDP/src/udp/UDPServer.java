package udp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPServer {
    public static void main(String[] argv) throws Exception {
        DatagramSocket socket = new DatagramSocket(12345);
        byte[] buffer = new byte[1024];

        // recibir el número de Cliente1
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.receive(packet);
        InetAddress addressCliente1 = packet.getAddress();
        int portCliente1 = packet.getPort();

        // enviar el número a Cliente2
        InetAddress addressCliente2 = InetAddress.getLocalHost();
        DatagramPacket packetCliente2 = new DatagramPacket(packet.getData(), packet.getLength(), addressCliente2, 34568);
        socket.send(packetCliente2);

        // recibir el factorial de Cliente2
        packet = new DatagramPacket(buffer, buffer.length);
        socket.receive(packet);

        // enviar el factorial a Cliente1
        DatagramPacket packetCliente1 = new DatagramPacket(packet.getData(), packet.getLength(), addressCliente1, portCliente1);
        socket.send(packetCliente1);

        socket.close();
    }
}




