package udp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class UDPClient1 {
    public static void main(String[] args) throws Exception {
        DatagramSocket socket = new DatagramSocket(34567);
        InetAddress address = InetAddress.getLocalHost();
        byte[] buffer;

        // solicitar un número al usuario
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un número: ");
        String numero = scanner.nextLine();

        // enviar el número al servidor
        buffer = numero.getBytes();
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length, address, 12345);
        socket.send(packet);

        // limpiar el buffer antes de recibir
        buffer = new byte[1024];
        packet = new DatagramPacket(buffer, buffer.length);

        // recibir el factorial del servidor
        socket.receive(packet);
        String mensaje = new String(packet.getData(), 0, packet.getLength());
        System.out.println("El factorial del número es: " + mensaje.trim());

        socket.close();
    }
}