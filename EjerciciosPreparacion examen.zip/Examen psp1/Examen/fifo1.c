#include <sys/types.h>

#include <fcntl.h>

#include <unistd.h>

#include <stdio.h>

#include <stdlib.h>

#include <sys/wait.h>

#include <sys/stat.h>

#include <math.h>

int main(void) {
  int fp;
  int p;
  double bytesleidos;
  char buffer[10];
  double c;
  double porcentaje;
  double atotales;
  char texto[1] = "a";
  p = mkfifo("FIFO2", S_IFIFO | 0666); //permiso  de  lecture y escritura
  fp = open("FIFO2", 0);
  //leo los valores que le he mandado anteriormente
  read(fp, & c, sizeof(c));
  read(fp, & porcentaje, sizeof(porcentaje));
  read(fp, & atotales, sizeof(atotales));
  close(fp);
  printf("El valor es %lf\n", c);
  printf("El valor es %lf\n", porcentaje);
  printf("El valor es %lf\n", atotales);
  //calculo el resultado 
  double var1 = c;
  double var2 = porcentaje;
  double var3 = atotales;
  double operacion;
  double parte1;
  double parte2;
  parte1 = var2 * pow((1 + var2), var3);
  parte2 = pow((1 + var2), var3) - 1;
  operacion = var1 * ((var2 * pow((1 + var2), var3)) / (pow((1 + var2), var3) - 1));
  printf("El valor es %lf\n", operacion);
  sprintf(buffer, "%lf", operacion);
  printf("El valor es %s\n", buffer);
  //escribo el resultado para mandarlo
  fp = open("FIFO2", 1);
  write(fp, buffer, sizeof(buffer));
  close(fp);
}
