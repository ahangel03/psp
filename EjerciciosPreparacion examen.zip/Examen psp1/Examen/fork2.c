#include <stdio.h>
#include <unistd.h>

int main() {
    pid_t p1, p2, p3, p4;

    // Proceso p1 (padre)
    p1 = getpid();
    printf("p1 (Padre): PID = %d\n", p1);

    // Proceso p2 (hijo de p1)
    p2 = fork();
    if (p2 == 0) {
        printf("p2 (Hijo de p1): PID = %d, PPID = %d\n", getpid(), getppid());

        // Proceso p3 (hijo de p2)
        p3 = fork();
        if (p3 == 0) {
            printf("p3 (Hijo de p2): PID = %d, PPID = %d\n", getpid(), getppid());

            // Proceso p4 (hijo de p3)
            p4 = fork();
            if (p4 == 0) {
                printf("p4 (Hijo de p3): PID = %d, PPID = %d\n", getpid(), getppid());
            }
        }
    }

    return 0;
}