#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

void main(){
     int fd[2]; 
     char buffer[30];
     pid_t pid;
     int dni;
     char letra[] = "TRWAGMYFPDXBNJZSQVHLCKE";
     int valor;  
     pipe(fd); 
     pid = fork();
     if (pid==0)
     {
                close(fd[0]); 
                printf("Introduzca el numero de tu dni:\n");
                scanf("%d",&valor);
                sprintf(buffer,"%d",valor);
                write(fd[1],buffer, sizeof(buffer));   
     }
     else
     {
                close(fd[1]); 
	        read(fd[0],buffer,sizeof(buffer));
		printf("%s",buffer);
		dni=atoi(buffer);
	        dni%=23;
	        printf("la letra del NIF es:%c",letra[dni]);
     	        wait(NULL);
     }
     
        
}
