#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

int main()
{
    int fp;
    int numero;
    char buffer[10];
    int bytesleidos;

    mkfifo("FIFO1", S_IFIFO | 0666); // Permiso de lectura y escritura
    fp = open("FIFO1", 1); // 1 = modo escritura 0 = modo lectura. Es decir el descriptor
    // se utiliza para escribir en el FIFO
   
    numero = 1 + rand() % 10; // num aleatorio entre 1 y 10
   
    printf("Mandando información al FIFO...\n");
    write(fp, &numero, sizeof(numero));  // escritura del numero en el FIFO
    close(fp);

    fp = open("FIFO2", 0); //fifo modo lectura
    bytesleidos = read(fp, buffer, sizeof(buffer)); //lecutra de los datos en el fifo2 y lo almacenamos en el buffer

//impresión de los datos leídos para que los pueda leer el usuario
    printf("Resultado del cálculo: ");
    while (bytesleidos != 0)
    {
        printf("%s", buffer);
        bytesleidos = read(fp, buffer, sizeof(buffer)); // Leo otro bloque de bytes
    }

    close(fp);

    // Eliminar los pipes
    unlink("FIFO1");
    unlink("FIFO2");

    return 0;
}