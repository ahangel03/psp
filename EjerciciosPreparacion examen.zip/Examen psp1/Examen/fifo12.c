#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

 
int main(void)
{
    int fp;
    char buffer[10];
    int numero;
    int factorial_numero;
    char resultado[50];

   
    mkfifo("FIFO2", S_IFIFO | 0666); // Permiso de lectura y escritura

    while (1)
    {
        fp = open("FIFO1", 0); // Abrimos FIFO1 en modo solo lectura (1 sería en modo escritura
        read(fp, buffer, sizeof(buffer));
        close(fp);

        sscanf(buffer, "%d", &numero); // Se extrae el número del buffer y se almacena en la variable numero

        // Calculamos el factorial del numero
       int factorial = 1;
       for(int i = 1; i<= numero; i++){
       factorial *= 1;
       }

        // Generamos un mensaje que contenga el factorial del numero calculado
        sprintf(resultado, "El factorial de %d es %d\n", numero, factorial_numero);

        fp = open("FIFO2", 1);
        write(fp, resultado, strlen(resultado));
        close(fp);
    }

    return 0;
}