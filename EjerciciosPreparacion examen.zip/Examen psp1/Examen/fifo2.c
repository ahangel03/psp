#include <sys/types.h>

#include <fcntl.h>

#include <unistd.h>

#include <stdio.h>

#include <stdlib.h>

#include <sys/wait.h>

#include <math.h>

#include <sys/stat.h>

int main() {
  int fp, bytesleidos;
  char buffer[20];
  double c;
  double a;
  double n;
  double operacion;
  fp = open("FIFO2", 1); //abro el fifo e introduzco los datos requeridos
  printf("Introduce el capital \n");
  scanf(" %lf", & c);
  printf("El capital ingresado es de %lf\n", c);
  printf("Introduce los porcentajes \n");
  scanf(" %lf", & a);
  printf("Los porcentajes ingresados son  %lf\n", a);
  printf("Introduce n \n");
  scanf(" %lf", & n);
  printf("El n  %lf\n", n);

  //calculo los datos antes de mandarlos
  printf("Mandando  informacion  al  FIFO...\n");
  double porcentaje;
  porcentaje = a / (12 * 100);
  printf("Los porcentajes ingresados son  %lf\n", porcentaje);
  double atotales;
  atotales = n * 12;
  printf("Los años ingresados son  %lf\n", atotales);
  //escribo los datos en el fifo
  write(fp, & c, sizeof(c));
  write(fp, & porcentaje, sizeof(porcentaje));
  write(fp, & atotales, sizeof(atotales));
  close(fp);
  //leo el resultado del fifo
  fp = open("FIFO2", 0); //abro el fifo e introduzco los datos requeridos
  read(fp, buffer, sizeof(buffer));
  printf("El resultado es %s\n", buffer);;
  close(fp);
  return 0;
}
