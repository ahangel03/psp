package sockets;

import java.io.*;
import java.net.*;

public class cliente2  {
  public static void main(String[] args) throws Exception {
	String Host = "localhost";
	int Puerto = 6969;//puerto remoto	
	
	System.out.println("PROGRAMA CLIENTE INICIADO....");
	Socket cliente2 = new Socket(Host, Puerto);




	// Creación flujo de entrada desde el servidor
	DataInputStream flujoEntrada = new  DataInputStream(cliente2.getInputStream());
	double numero = flujoEntrada.readDouble();
	double factorial = 1;
     for (int i = 1; i <= numero; i++) {
         factorial *= i;
     }
 	// Creación flujo de salida hacia el servidor
 	DataOutputStream flujoSalida = new DataOutputStream(cliente2.getOutputStream());
     flujoSalida.writeDouble(factorial);

	

	// CERRAR STREAMS Y SOCKETS	
	flujoEntrada.close();	
	flujoSalida.close();	
	cliente2.close();	
  }// main
}// 
