package sockets;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.*;
import java.util.Scanner;
public class cliente1 {
  public static void main(String[] args) {
         String host="localhost";
         int puerto=6969;
         double numero;
        try 
        {

        Socket cliente1 = new Socket(host,puerto); //Se crea socket de cliente y lo asocia al puerto indicado del host
        System.out.println("Cliente escuchando en: "+ cliente1.getLocalPort());
        System.out.println("Cliente conectado a puerto remoto: "+ cliente1.getPort());

        
       try (Scanner sc = new Scanner(System.in)) {
		System.out.println("Ingrese un numero: ");
		   numero = sc.nextDouble();
	}
       // Creación flujo de salida hacia el servidor
   	DataOutputStream flujoSalida = new DataOutputStream(cliente1.getOutputStream());
   	flujoSalida.writeDouble(numero);
   	
    //flujo de entrada desde el servidor
   	DataInputStream flujoEntrada = new  DataInputStream(cliente1.getInputStream());
   	double factorial = flujoEntrada.readDouble();
   	
   	System.out.println("El factorial de " + numero + " es " + factorial);
       
        InetAddress ip= cliente1.getInetAddress();
        System.out.println("Máquina remota: "+ ip.getHostName().toString());
        System.out.println("IP Máquina remota: "+ ip.getHostAddress().toString());
        
        cliente1.close(); //Cierre del socket

         } catch (IOException excepcion) {excepcion.getMessage()	;  }
  }
  
}