package sockets;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.*;

	public class servidor {
	  public static void main(String[] args) {
	        int puerto=6969;
	        try 
	        {
	        	
	        ServerSocket Servidor = new ServerSocket(puerto); //Se crea socket de servidor asociado al puerto
	        System.out.println("Servidor escuchando en "+ Servidor.getLocalPort());


	        
	        Socket cliente1= Servidor.accept(); //Esperando conexión cliente
	        System.out.println("Cliente 1 conectado");
	        
	      //Recibir numero del cliente1
	        DataInputStream flujoEntrada1 = new  DataInputStream(cliente1.getInputStream());
	    	double numero = flujoEntrada1.readDouble();
	    	
	    	// Esperar la conexión del cliente 2
            Socket cliente2 = Servidor.accept();
            System.out.println("Cliente 2 conectado");
            //Aquí irían todas las acciones a realizar con el cliente2
            
            // Enviar número al cliente 2
	    	DataOutputStream flujoSalida2 = new DataOutputStream(cliente2.getOutputStream());
	    	flujoSalida2.writeDouble(numero);
	    	
	    	 // Recibir factorial del cliente 2
            DataInputStream flujoEntrada2 = new DataInputStream(cliente2.getInputStream());
            double factorial = flujoEntrada2.readDouble();
            
            // Enviar factorial al cliente 1
            DataOutputStream flujoSalida1 = new DataOutputStream(cliente1.getOutputStream());
	    	flujoSalida1.writeDouble(factorial);
	    	
	    	 // Cerrar conexiones
            flujoEntrada1.close();
            flujoEntrada2.close();
            flujoSalida1.close();
            flujoSalida2.close();
            cliente1.close();
            cliente2.close();
            Servidor.close();

	     

	         } catch (IOException excepcion) {  excepcion.printStackTrace();	;  }
	  }
	  
	}
