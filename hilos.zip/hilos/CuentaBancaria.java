package hilos;


public	class CuentaBancaria {
	    private int saldo = 1000;

	    public synchronized void sacarDinero(String nombre, int importe) {
	        if (saldo >= importe) {
	            System.out.println(nombre + " retira $" + importe + ". Saldo restante: $" + (saldo - importe));
	            saldo -= importe;
	        } else {
	            System.out.println(nombre + ": Saldo insuficiente para retirar $" + importe);
	        }

	        try {
	            Thread.sleep(1000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }

	    public synchronized void ingresarDinero(String nombre, int importe) {
	        System.out.println(nombre + " deposita $" + importe + ". Saldo actual: $" + (saldo + importe));
	        saldo += importe;

	        try {
	            Thread.sleep(1000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
	}

	

	

