package hilos;

public class HiloSacarDinero implements Runnable {
    private CuentaBancaria cuenta;
    private String nombre;
    private int cantidad;

    public HiloSacarDinero(CuentaBancaria cuenta, String nombre, int cantidad) {
        this.cuenta = cuenta;
        this.nombre = nombre;
        this.cantidad = cantidad;
    }

    public void run() {
        cuenta.sacarDinero(nombre, cantidad);
    }
}
