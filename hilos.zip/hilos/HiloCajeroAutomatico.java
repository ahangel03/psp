package hilos;


public class HiloCajeroAutomatico {
    public static void main(String[] args) {
        CuentaBancaria cuenta = new CuentaBancaria();

       
        Thread hilo2 = new Thread(new HiloIngresarDinero(cuenta, "María", 200));
        Thread hilo3 = new Thread(new HiloSacarDinero(cuenta, "Pedro", 800));
        Thread hilo1 = new Thread(new HiloSacarDinero(cuenta, "Juan", 500));
        Thread hilo4 = new Thread(new HiloIngresarDinero(cuenta, "Ana", 300));

      
        hilo4.start();
        hilo2.start();
        hilo1.start();
        hilo3.start();
      
    }
}
